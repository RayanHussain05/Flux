# FLUX: Good-Day Pact — Live demo talk track

## The 20-second opening

Imagine a person going through a severe depressive episode. Their rent is coming up. They know they need to act, but cannot face opening their banking app. Most tools expect a customer to act **right when life becomes hardest**. FLUX is designed for the opposite reality.

## Walkthrough — Good Day

Alex describes the situation in ordinary language. With explicit opt-in, **Claude** suggests useful scenarios and protective rules; it has **no authority to execute them**. The numbers are fictional and the forecast is a deterministic 30-day simulation showing a range of possible outcomes. We distinguish that from predicting mental health.

## Walkthrough — Pact

Alex chooses exactly what FLUX is allowed to do. Here: pause a future *optional savings transfer*, prepare a landlord letter for review, and optionally schedule a neutral trusted-person alert. Alex ticks a separate consent checkbox. A landlord must agree to any proposed rent-date change.

## Walkthrough — Difficult Day

Fast-forward. FLUX's transparent rules engine reuses the same financial simulation and finds a projected funding gap. It **simulates** pausing the authorised £40 savings transfer. It never cancels an essential bill or changes a contractual rent date.

## Walkthrough — Safe Landing

The £40 protection closes the **immediate** rent gap in this scenario. But the wider 30-day projection still shows a **£77** later risk, which is flagged rather than hidden. The hardship letter is a draft, not a message sent. The audit trail explains everything. Reset and enable the additional £60 shock for a shortfall the pact cannot resolve.

## 20-second closing

Most financial tools tell you what to do when a problem arrives. FLUX lets you **make the decision on a good day**, rehearse the outcome, and activate only those exact protections on a difficult day. We're not replacing people's decisions. We're helping them honour the decisions they already made for themselves.

## Q&A

- **Where is AI?** Claude interprets a story into suggested rules and financial assumptions. Each numeric suggestion is reviewed, and deterministic code does forecasting, authorisation and execution. Show the LIVE AI badge only after a confirmed model response.
- **Where does money come from?** FLUX protects available funds; it does not create money. It flags unresolved needs and prepares support requests.
- **How is this unique?** It links financial rehearsal, explicit pre-consent and controlled protective execution for people who struggle with financial admin at unpredictable times.
- **Does this work in real NatWest accounts?** Not yet. The demo's bank integration is simulated; the vision is a NatWest-native feature, contingent on real permissions, agreements and safeguards.
- **Privacy?** The live AI opt-in sends only the story text to Anthropic, so demo with fictional data. No story is deliberately persisted on the backend. Your host provider may process API requests under its policies.
