import test from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_FINANCES, evaluateForecast, simulatePaths, summarizePaths } from './finance.js';

test('forecast is deterministic and provides exactly 150 synthetic paths', () => {
  const a = simulatePaths(DEFAULT_FINANCES, false, 0);
  assert.equal(a.length, 150);
  assert.equal(a[0].length, 31);
  assert.deepEqual(a, simulatePaths(DEFAULT_FINANCES, false, 0));
});
test('a permitted transfer pause closes the rent-day £40 gap, but shows later risk', () => {
  const f = evaluateForecast(DEFAULT_FINANCES);
  assert.equal(f.before.rentGap, 40);
  assert.equal(f.after.rentGap, 0);
  assert.equal(f.paused, true);
  assert.ok(f.after.horizonGap > 0);
  assert.equal(f.after.horizonGap, 77);
});
test('the harder-case shock still leaves rent short and flags later problems', () => {
  const f = evaluateForecast(DEFAULT_FINANCES, { extraShock: 60 });
  assert.equal(f.after.rentGap, 60);
  assert.equal(f.after.horizonGap, 137);
});
test('nothing is paused unless it has been authorised', () => {
  const f = evaluateForecast(DEFAULT_FINANCES, { permitPause: false });
  assert.equal(f.paused, false);
  assert.deepEqual(f.before, f.after);
});
test('the safety buffer is included in the 30-day gap', () => {
  const f0 = evaluateForecast(DEFAULT_FINANCES);
  const f50 = evaluateForecast(DEFAULT_FINANCES, { safetyBuffer: 50 });
  assert.equal(f50.after.horizonGap, f0.after.horizonGap + 50);
});
test('summary respects rent date and yields 31 bands', () => {
  const s = summarizePaths(simulatePaths(DEFAULT_FINANCES), 10, 0);
  assert.equal(s.bands.length, 31);
  assert.equal(s.rentBalance, -40);
});
