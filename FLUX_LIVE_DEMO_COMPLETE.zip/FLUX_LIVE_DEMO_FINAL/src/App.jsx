import React, { useEffect, useMemo, useState } from 'react';
import { DEFAULT_FINANCES, clampNumber, evaluateForecast, money, signedMoney } from './finance.js';

const DEFAULT_STORY = "Some weeks my mental health makes it difficult to open banking apps or reply to messages. I might miss three weeks of shifts. My £650 rent is my priority, and I have an optional £40 savings transfer coming up. I want to make sure rent is protected.";
const STAGES = [
  { id: 'rehearse', name: 'Rehearse', detail: 'Understand the risk', emoji: '☀' },
  { id: 'pact', name: 'Make your pact', detail: 'Decide in advance', emoji: '✧' },
  { id: 'difficult', name: 'Difficult day', detail: 'Let your rules work', emoji: '◑' },
  { id: 'landing', name: 'Safe landing', detail: 'See what happened', emoji: '✓' },
];

function offlineSuggestions(story) {
  const text = story.toLowerCase();
  const housing = /rent|landlord|mortgage|housing/.test(text);
  const income = /work|shifts?|hours|pay|wages|income|universal credit|pension/.test(text);
  const admin = /overwhelm|mental|health|depress|anxie|stress|hard|difficult|can't|cannot|manage|struggl|forget/.test(text);
  const insights = [];
  if (housing) insights.push({ icon: '⌂', heading: 'Keep housing secure', detail: 'Make sure essential housing costs come first.' });
  if (income) insights.push({ icon: '◷', heading: 'Prepare for uncertain income', detail: 'Model how reduced income might affect important payments.' });
  if (admin) insights.push({ icon: '✧', heading: 'Reduce decisions on hard days', detail: 'Prepare simple, pre-approved instructions in advance.' });
  if (insights.length === 0) insights.push({ icon: '✧', heading: 'Protect what matters', detail: 'Identify essential payments and prepare for a difficult month.' });
  return {
    summary: housing ? 'You want to protect housing costs and make financial admin easier during difficult weeks.' : 'You want a financial safety net that respects your circumstances.',
    insights,
    suggested_rules: [...(housing ? ['pause', 'draft'] : []), ...(admin ? ['contact'] : [])],
    scenario: {},
    mode: 'offline-rules'
  };
}

function ForecastChart({ forecast, rentDay = 10, buffer = 0 }) {
  const width = 790, height = 300;
  const margin = { left: 55, right: 15, top: 25, bottom: 39 };
  const data = forecast.before.bands;
  const protectedData = forecast.after.bands;
  const all = [...data, ...protectedData].flatMap(row => [row.low, row.median, row.high]);
  const lo = Math.min(-120, ...all) - 75;
  const hi = Math.max(800, ...all) + 60;
  const x = d => margin.left + (width - margin.left - margin.right) * d / 30;
  const y = v => margin.top + (height - margin.top - margin.bottom) * (hi - v) / (hi - lo);
  const path = (arr, field) => arr.map((p, i) => `${i === 0 ? 'M' : 'L'} ${x(i).toFixed(2)} ${y(p[field]).toFixed(2)}`).join(' ');
  const shade = path(data, 'high') + ' ' + data.slice().reverse().map((p, i) => `L ${x(30 - i).toFixed(2)} ${y(p.low).toFixed(2)}`).join(' ') + ' Z';
  const ticks = [0, 1, 2, 3, 4].map(i => lo + (hi - lo) * i / 4);
  return (
    <div className="forecast-wrap">
      <div className="chart-legend"><span><i className="key-line purple" />Without pact</span><span><i className="key-band" />Range of outcomes</span><span><i className="key-line mint" />With pact</span></div>
      <svg className="forecast-chart" viewBox={`0 0 ${width} ${height}`} role="img" aria-label="30-day account balance forecast with uncertainty band, £0 threshold, rent day and possible protection">
        <defs><linearGradient id="riskBand" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#cdb9fc" stopOpacity=".52"/><stop offset="1" stopColor="#d1c5f5" stopOpacity=".08"/></linearGradient></defs>
        {ticks.map((tick, i) => <g key={i}><line x1={margin.left} y1={y(tick)} x2={width-margin.right} y2={y(tick)} stroke="#e4e2eb" strokeDasharray="4 5"/><text x={margin.left-12} y={y(tick)+4} textAnchor="end" className="chart-axis">{Math.round(tick) < 0 ? '−' : ''}£{Math.abs(Math.round(tick))}</text></g>)}
        <path d={shade} fill="url(#riskBand)" />
        <line x1={margin.left} x2={width-margin.right} y1={y(buffer)} y2={y(buffer)} stroke="#d75d75" strokeDasharray="5 5" strokeWidth="1.7" />
        <text x={width-margin.right-8} y={y(buffer)-8} textAnchor="end" className="zero-label">{money(buffer)} SAFETY THRESHOLD</text>
        <line x1={x(rentDay)} x2={x(rentDay)} y1={margin.top} y2={height-margin.bottom} stroke="#c6acef" strokeDasharray="4 5" />
        <rect x={x(rentDay)-39} y="9" width="78" height="22" rx="7" fill="#f4ebff" />
        <text x={x(rentDay)} y="24" textAnchor="middle" className="rent-marker">RENT DUE</text>
        <path d={path(data, 'median')} fill="none" stroke="#7655c8" strokeWidth="3.2" strokeLinejoin="round" strokeLinecap="round" />
        <path d={path(protectedData, 'median')} fill="none" stroke="#0caa8e" strokeWidth="3.2" strokeLinejoin="round" strokeLinecap="round" strokeDasharray="8 6" />
        {[0, 5, 10, 15, 20, 25, 30].map(day => <text key={day} x={x(day)} y={height-9} textAnchor="middle" className="chart-axis">{day===0?'Today':`Day ${day}`}</text>)}
        <circle cx={x(rentDay)} cy={y(data[rentDay].median)} r="5.5" fill="#7655c8" stroke="white" strokeWidth="2" />
        <circle cx={x(rentDay)} cy={y(protectedData[rentDay].median)} r="5.5" fill="#0caa8e" stroke="white" strokeWidth="2" />
      </svg>
      <p className="small muted chart-note">150 reproducible fictional outcomes · shaded area = 10th–90th percentile · £850 fictional income on day 17</p>
    </div>
  );
}

function Metric({ label, value, tone = '', detail }) {
  return <div className={`metric-card ${tone}`}><div className="metric-label">{label}</div><div className="metric-value">{value}</div>{detail && <div className="metric-detail">{detail}</div>}</div>;
}
function SectionHeader({ eyebrow, title, description }) {
  return <div className="section-heading"><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>;
}
function Field({ label, value, onChange, disabled, max = 20000 }) {
  return <label className="field"><span>{label}</span><span className="currency-input"><span>£</span><input aria-label={label} type="number" min="0" max={max} value={value} disabled={disabled} onChange={e => onChange(clampNumber(e.target.value, 0, 0, max))}/></span></label>;
}
function Rule({ selected, onChange, label, description, disabled, icon = '✓' }) {
  return <label className={`rule ${selected?'chosen':''} ${disabled?'disabled':''}`}><input type="checkbox" checked={selected} onChange={e => onChange(e.target.checked)} disabled={disabled}/><div className="rule-symbol">{icon}</div><div className="rule-copy"><strong>{label}</strong><small>{description}</small></div><span className="rule-check">{selected?'✓':'+'}</span></label>;
}
function createLetter(rent) {
  return `Dear Landlord,\n\nI'm writing about my upcoming rent payment of ${money(rent)}. I want to keep on top of my housing payments, but my financial circumstances are uncertain and I may need some temporary flexibility.\n\nCould we discuss whether a temporary payment arrangement or change of payment date could be possible if I have difficulty paying on the agreed date? I understand that any change requires your agreement, and I'd appreciate written confirmation.\n\nPlease let me know what options might be available.\n\nKind regards,\nAlex\n\n[Draft for review only — not sent. Confirm the details before using.]`;
}

function App() {
  const [stage, setStage] = useState('rehearse');
  const [story, setStory] = useState(DEFAULT_STORY);
  const [finances, setFinances] = useState(DEFAULT_FINANCES);
  const [buffer, setBuffer] = useState(0);
  const [analysis, setAnalysis] = useState(null);
  const [analysisStatus, setAnalysisStatus] = useState('Ready. Choose live Claude AI if you want generative suggestions, then click Understand my situation.');
  const [analysisError, setAnalysisError] = useState('');
  const [backendHealth, setBackendHealth] = useState(null);
  const [liveAi, setLiveAi] = useState(false);
  const [busy, setBusy] = useState(false);
  const [suggestionPending, setSuggestionPending] = useState(null);
  const [rules, setRules] = useState({ pause: true, draft: true, contact: false });
  const [contactName, setContactName] = useState('Sam');
  const [consentChecked, setConsentChecked] = useState(false);
  const [pact, setPact] = useState(null);
  const [shock, setShock] = useState(false);
  const [missedCheckin, setMissedCheckin] = useState(false);
  const [execution, setExecution] = useState(null);
  const [revoked, setRevoked] = useState(false);
  const [letterOpen, setLetterOpen] = useState(false);
  const [lowEnergy, setLowEnergy] = useState(false);
  const [toast, setToast] = useState('');
  const locked = pact !== null;
  const forecast = useMemo(() => evaluateForecast(finances, { permitPause: rules.pause, safetyBuffer: buffer }), [finances, rules.pause, buffer]);
  const pactForecast = useMemo(() => pact ? evaluateForecast(pact.finances, { permitPause: pact.rules.pause, safetyBuffer: pact.buffer, extraShock: shock ? 60 : 0 }) : null, [pact, shock]);
  const hasRights = pact && !revoked;
  const canRun = pact && !execution && !revoked;
  const clearToast = message => {setToast(message); window.setTimeout(() => setToast(''), 4500);};
  async function checkBackend() {
    try {
      const response = await fetch('/api/health', {cache:'no-store'});
      if (!response.ok) throw new Error('Backend unavailable');
      const data = await response.json();
      setBackendHealth({ok:true, configured:Boolean(data.claude_configured)});
    } catch {
      setBackendHealth({ok:false, configured:false});
    }
  }
  useEffect(() => { checkBackend(); }, []);

  function updateFinance(name, value) {
    if (locked) return;
    setFinances(previous => ({...previous, [name]: value}));
  }
  function navigate(next) {
    if (next === 'difficult' && !pact) {setStage('pact'); clearToast('Authorise a pact first.'); return;}
    if (next === 'landing' && !execution) {clearToast('Run the difficult-day simulation first.'); return;}
    setStage(next);
    window.scrollTo({top:0, behavior:'smooth'});
  }
  async function interpret() {
    if (story.trim().length < 12) {
      setAnalysisError('Write at least a sentence to describe your situation.');
      setAnalysisStatus('Please enter more detail.');
      return;
    }
    setBusy(true);
    setAnalysis(null);
    setAnalysisError('');
    setSuggestionPending(null);
    if (!liveAi) {
      setAnalysis(offlineSuggestions(story));
      setAnalysisStatus('Offline interpretation complete. These are rule-based suggestions, not a Claude response.');
      setBusy(false);
      return;
    }
    setAnalysisStatus('Contacting Claude through your local Python server…');
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 35000);
    try {
      const response = await fetch('/api/interpret', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({story}), signal: controller.signal
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        const detail = typeof payload.error === 'string' ? payload.error : `Backend HTTP ${response.status}`;
        throw new Error(detail);
      }
      if (typeof payload.summary !== 'string' || !Array.isArray(payload.insights)) {
        throw new Error('The server returned a reply in an unexpected format.');
      }
      setAnalysis(payload);
      setSuggestionPending(payload.scenario ?? null);
      setAnalysisStatus('Live Claude response received. Suggested actions still require your explicit approval.');
    } catch (error) {
      let message = error?.message || 'Unknown request error';
      if (error?.name === 'AbortError') message = 'Claude did not respond within 35 seconds. Try again.';
      else if (/failed to fetch|networkerror|load failed/i.test(message)) message = 'Cannot reach the Python backend. Check that python backend/server.py is still running on port 8765.';
      setAnalysisError(`Live Claude request failed: ${message}`);
      setAnalysisStatus('Live Claude did not respond. Nothing was authorised or sent.');
    } finally {
      window.clearTimeout(timer);
      setBusy(false);
    }
  }
  function useOfflineInstead() {
    setAnalysis(offlineSuggestions(story));
    setAnalysisError('');
    setSuggestionPending(null);
    setAnalysisStatus('Offline, rule-based suggestions shown. Claude was not used.');
  }
  function acceptProposedNumbers() {
    if (!suggestionPending || locked) return;
    setFinances(current => ({
      ...current,
      ...Object.fromEntries([
        ['balance', 20000], ['rent', 20000], ['savings', 5000], ['lostWeeks', 4]
      ].filter(([k])=>typeof suggestionPending[k] === 'number').map(([k,max])=>[k,clampNumber(suggestionPending[k], current[k],0,max)]))
    }));
    setSuggestionPending(null);
    clearToast('AI-suggested numbers applied for your review. No rules were authorised.');
  }
  function authorise() {
    if (!consentChecked) {clearToast('Please confirm consent before authorising.'); return;}
    if (!Object.values(rules).some(Boolean)) {clearToast('Choose at least one protective rule.'); return;}
    const snapshot = {finances: {...finances}, rules: {...rules}, buffer, contactName:contactName.trim()||'trusted person'};
    setPact(snapshot);
    setRevoked(false);
    setExecution(null);
    setStage('difficult');
    clearToast('Pact authorised. Only these specific rules can run in the simulated bank.');
  }
  function fastForward() {
    if (!canRun) return;
    const f = evaluateForecast(pact.finances, { extraShock: shock ? 60 : 0, permitPause: pact.rules.pause, safetyBuffer: pact.buffer });
    const log = [
      {title:'30-day forecast checked', detail:`Before protection, the median balance reaches ${signedMoney(f.before.minimum)} on day ${f.before.minDay}; projected rent gap ${money(f.before.rentGap)}.`, kind:'info'},
      f.paused ? {title:'Optional savings transfer paused', detail:`The mock bank retained ${money(pact.finances.savings)} for essential spending. No new money was created.`, kind:'done'} : {title:'Transfer unchanged', detail: pact.rules.pause ? 'The pause trigger was not reached.' : 'No permission to pause this transfer.', kind:'info'}
    ];
    const letterReady = pact.rules.draft && (f.after.rentGap > 0 || f.after.horizonGap > 0);
    if (letterReady) log.push({title:'Hardship letter prepared', detail:'Draft generated for review only. Not sent to the landlord.', kind:'info'});
    if (pact.rules.contact && missedCheckin) log.push({title:'Neutral check-in simulated', detail:`One pre-authorised alert to ${pact.contactName}; no balances or health details shared.`, kind:'done'});
    else if (pact.rules.contact) log.push({title:'Trusted person not notified', detail:'Separate missed-check-in trigger did not occur.',kind:'info'});
    if (f.after.horizonGap > 0) log.push({title:'Remaining risk flagged', detail:`Rent gap ${money(f.after.rentGap)}, full 30-day gap ${money(f.after.horizonGap)}, including the ${money(pact.buffer)} safety buffer. Human support suggested.`,kind:'warn'});
    else log.push({title:'No remaining 30-day median gap', detail:'This is only a simulation and does not guarantee real-world outcomes.',kind:'done'});
    setExecution({forecast:f, retained:f.paused?pact.finances.savings:0, letterReady, log});
    setStage('landing');
    clearToast('Simulation complete. The chart, rule trigger and result share the same financial model.');
  }
  function revoke() {
    setRevoked(true);
    if (execution) setExecution(old => ({...old, log:[...old.log,{title:'Future permissions revoked', detail:'No future actions can run. Past simulated actions remain in the audit trail.',kind:'warn'}]}));
    clearToast('Future permissions revoked. Completed simulated actions are not undone.');
  }
  function editPact() {
    setPact(null); setExecution(null); setRevoked(false); setConsentChecked(false);
    setShock(false); setMissedCheckin(false); setStage('pact');
    clearToast('Review and re-authorise your revised pact.');
  }
  function reset() {
    setStage('rehearse'); setStory(DEFAULT_STORY); setFinances(DEFAULT_FINANCES); setBuffer(0);
    setAnalysis(null); setAnalysisStatus('Ready. Click Understand my situation to generate suggestions.'); setAnalysisError('');
    setLiveAi(false); setRules({pause:true,draft:true,contact:false}); setContactName('Sam');
    setConsentChecked(false); setPact(null); setExecution(null); setRevoked(false);
    setShock(false); setMissedCheckin(false); setSuggestionPending(null); setLetterOpen(false);
    clearToast('Demo reset to the Good Day screen.');
  }
  const retained = execution?.retained ?? 0;
  const result = execution?.forecast;
  return <div className={`app-shell ${lowEnergy?'low-energy':''}`}>
    <aside className="sidebar">
      <button className="brand" onClick={()=>navigate('rehearse')}><span className="brand-icon">⌁</span><span className="brand-text">flux<span className="brand-period">.</span><small>GOOD-DAY PACT</small></span></button>
      <div className="sidebar-heading">YOUR JOURNEY</div>
      <nav aria-label="Prototype stages" className="nav-list">{STAGES.map((s,i) => <button key={s.id} type="button" className={`nav-item ${stage===s.id?'selected':''}`} onClick={()=>navigate(s.id)}><span className="nav-number">{String(i+1).padStart(2,'0')}</span><span><strong>{s.name}</strong><small>{s.detail}</small></span><span className="nav-chevron">›</span></button>)}</nav>
      <div className="sidebar-foot"><div className="sidebar-quote"><span>✳</span><strong>Designed for real life.</strong><p>Because some days, the hardest part is having to act.</p></div><small>GreatUniHack 2026 concept<br/>Not a NatWest product · Fictional data</small></div>
    </aside>
    <div className="main-wrap">
      <header className="topbar"><div className="crumb"><span className="green-dot"/> FLUX PROTOTYPE <span className="slash">/</span> {STAGES.find(s=>s.id===stage)?.name}</div><div className="top-actions"><button className="quiet-btn" onClick={()=>setLowEnergy(!lowEnergy)} aria-pressed={lowEnergy}>◐ <span>Low-energy view</span></button><span className="demo-tag">● DEMO MODE</span><span className="avatar">A</span></div></header>
      <main className="content">
        {stage==='rehearse' && <>
          <SectionHeader eyebrow="01 / THE GOOD DAY" title={<>Plan for the days <em>you can't.</em></>} description="You make the decisions now. Your future self gets the breathing room." />
          <div className="two-columns intro-grid"><section className="panel"><div className="section-kicker">START WITH YOUR WORDS</div><h2>Tell FLUX what matters.</h2><p className="muted">There is no right way to explain it.</p><textarea className="story-input" value={story} maxLength={2400} onChange={e=>setStory(e.target.value)} disabled={locked} aria-label="Describe your circumstances" rows={5}/><div className="small muted count">{story.length} / 2400 characters</div>
            <div className="finance-fields"><div className="section-kicker">REVIEW FINANCIAL ASSUMPTIONS · FICTIONAL ACCOUNT</div><div className="three-fields"><Field label="Bank balance" value={finances.balance} disabled={locked} onChange={v=>updateFinance('balance',v)}/><Field label="Rent due" value={finances.rent} disabled={locked} onChange={v=>updateFinance('rent',v)}/><Field label="Optional transfer" value={finances.savings} disabled={locked} max={5000} onChange={v=>updateFinance('savings',v)}/></div></div>
            <label className="live-consent"><input type="checkbox" checked={liveAi} onChange={e=>setLiveAi(e.target.checked)} disabled={locked}/> <span><strong>Use live Claude AI</strong><small>Optional opt-in. Sends only your written description to the configured Anthropic API. Use fictional information in this demo.</small></span></label>
            <div className="connection-state"><span>{backendHealth===null ? 'Checking AI backend…' : backendHealth.ok ? backendHealth.configured ? '● Python connected · Claude key detected (response untested)' : '● Python connected · no Claude key configured' : '● Python backend not reachable. Offline demo still works.'}</span><button type="button" onClick={checkBackend}>Refresh status</button></div>
            <button className="primary-button wide" disabled={busy||locked} onClick={interpret}>{busy?'Connecting to Claude…':'✧  Understand my situation'} <span>→</span></button><p className="small muted" role="status">{analysisStatus}</p>{analysisError && <div className="ai-error" role="alert"><strong>Claude connection issue</strong><p>{analysisError}</p><button className="outline-button" type="button" onClick={useOfflineInstead}>Use offline suggestions instead</button></div>}
          </section><section className="panel"><div className="section-kicker">SUGGESTIONS · NOT AUTHORISED</div><h2>Your priorities, understood.</h2>{analysis ? <><span className="pill subtle">{analysis.mode==='live-ai'?'CLAUDE · LIVE AI':'OFFLINE · RULE-BASED'}</span><p className="analysis-summary">{analysis.summary}</p><div className="insights">{analysis.insights.map((item,i)=><div className="insight" key={i}><span className="insight-icon">{item.icon||'✧'}</span><span><strong>{item.heading||item.title}</strong><small>{item.detail||item.explain}</small></span><span className="ok">✓</span></div>)}</div><hr/><div className="section-kicker">SUGGESTED PACT ACTIONS</div><div className="suggested-tags">{(analysis.suggested_rules||[]).length ? analysis.suggested_rules.map(r=><span className="pill" key={r}>{({pause:'Pause optional transfer',draft:'Prepare a letter',contact:'Trusted-person check-in'})[r]||r}</span>):<span className="small muted">No rules proposed. Choose your own in the pact step.</span>}</div></> : <div className="analysis-empty" aria-live="polite"><strong>{busy ? 'Thinking through your financial priorities…' : 'Your suggestions will appear here.'}</strong><p>{busy ? 'Please leave both React and Python terminals running.' : 'Describe your situation and click “Understand my situation”. Enable live Claude AI to use your hackathon API credits.'}</p></div>}{suggestionPending && Object.values(suggestionPending).some(v=>v!==null&&v!==undefined) && <div className="suggestion-review"><p className="small"><strong>AI extracted possible figures.</strong> Confirm them before applying — the model cannot set account values or permissions by itself.</p><button className="outline-button" onClick={acceptProposedNumbers} disabled={locked}>Apply figures for review</button></div>}<div className="notice">ⓘ &nbsp; FLUX never diagnoses health conditions, interprets inactivity as illness, or authorises actions from AI text.</div></section></div>
          <div className="forecast-grid"><section className="panel"><div className="section-kicker">FINANCIAL TIME TRAVEL</div><h2>What if the next few weeks are hard?</h2><div className="sliders"><label>Weeks of disrupted shift income <strong>{finances.lostWeeks}</strong><input type="range" min="0" max="4" step="1" value={finances.lostWeeks} disabled={locked} onChange={e=>updateFinance('lostWeeks', Number(e.target.value))}/></label><label>Unexpected extra expense <strong>{money(finances.extraCost)}</strong><input type="range" min="0" max="120" step="20" value={finances.extraCost} disabled={locked} onChange={e=>updateFinance('extraCost', Number(e.target.value))}/></label></div><ForecastChart forecast={forecast} rentDay={finances.rentDay} buffer={buffer}/><p className="chart-warning"><strong>30-day safety check:</strong> Even with the proposed pact, the median reaches {signedMoney(forecast.after.minimum)} on day {forecast.after.minDay}. {forecast.after.horizonGap>0?`That leaves a ${money(forecast.after.horizonGap)} gap to your selected buffer.`:'The median stays above your buffer.'}</p></section>
            <aside className="side-stack"><div className="panel"><div className="section-kicker">ESSENTIAL PAYMENT</div><div className="rent-item"><span className="rent-icon">⌂</span><div><strong>Rent payment</strong><small>Due in 10 days</small></div><strong>{money(finances.rent)}</strong></div><hr/><p className="small muted">Projected rent-day shortfall without pact</p><div className="large-risk">{money(forecast.before.rentGap)}</div><p className="small muted">A transfer pause may protect rent, but later expenses can still cause a separate shortfall.</p></div><div className="nudge"><div>✦ &nbsp; THE GOOD-DAY DIFFERENCE</div><p>Decide what FLUX can do <strong>now</strong>, before a difficult week begins.</p><button onClick={()=>navigate('pact')} className="cream-button">Create my pact →</button></div></aside>
          </div>
        </>}
        {stage==='pact' && <>
          <SectionHeader eyebrow="02 / YOUR DECISIONS" title={<>Your safety net. <em>Your rules.</em></>} description="Choose what FLUX may do in the future. Nothing here is authorised until you confirm it."/>
          <div className="two-columns pact-grid"><section className="panel"><div className="section-kicker">PRE-AGREED PROTECTIVE ACTIONS</div><h2>What should happen if risk appears?</h2>
            <div className="rules"><Rule selected={rules.pause} disabled={locked} onChange={v=>setRules(r=>({...r,pause:v}))} label={`Pause optional ${money(finances.savings)} savings transfer`} description="Only if a simulated future financial shortfall crosses your chosen threshold. Does not cancel an essential bill." icon="◈"/><Rule selected={rules.draft} disabled={locked} onChange={v=>setRules(r=>({...r,draft:v}))} label="Prepare a landlord hardship letter" description="Drafted and ready for review, never sent automatically." icon="✉"/><Rule selected={rules.contact} disabled={locked} onChange={v=>setRules(r=>({...r,contact:v}))} label="Send a neutral trusted-person check-in" description="Only if a separately approved check-in trigger occurs. No financial or health details shared." icon="♡"/></div>
            {rules.contact && <label className="field contact-field">Trusted person's first name <input value={contactName} disabled={locked} onChange={e=>setContactName(e.target.value.slice(0,50))} maxLength={50}/></label>}
            <label className="field buffer-field">Safety buffer for the 30-day forecast <span className="currency-input"><span>£</span><input type="number" aria-label="Safety buffer" min="0" max="200" disabled={locked} value={buffer} onChange={e=>setBuffer(clampNumber(e.target.value,0,0,200))}/></span></label>
            <div className="notice">A pause is simulated and affects an optional transfer, not rent terms. A landlord must agree to any rent-date change.</div>
          </section><aside className="panel"><div className="section-kicker">CUSTOMER CONTROL</div><h2>Confirm your pact</h2><p className="muted">Your instructions are fixed once authorised. AI suggestions never become permissions automatically.</p><div className="summary-box"><div><span>Optional transfer</span><strong>{rules.pause?'Allowed to pause':'Not authorised'}</strong></div><div><span>Hardship letter</span><strong>{rules.draft?'Draft only':'Not authorised'}</strong></div><div><span>Trusted-person alert</span><strong>{rules.contact?'Separate opt-in trigger':'Not authorised'}</strong></div><div><span>Safety floor</span><strong>{money(buffer)}</strong></div></div><label className="consent-confirm"><input type="checkbox" checked={consentChecked} disabled={locked} onChange={e=>setConsentChecked(e.target.checked)}/><span>I understand and agree to these specific simulated actions. I can revoke future permissions at any time.</span></label>
            {!locked?<button className="primary-button wide" disabled={!consentChecked||!Object.values(rules).some(Boolean)} onClick={authorise}>Authorise my Good-Day Pact <span>→</span></button>:<div className="authorised-box">✓ Pact authorised. Your rules are locked for this run.<button className="outline-button" onClick={editPact}>Edit and re-authorise</button></div>}
            <p className="small muted">All banking actions are simulated for the hackathon. No real payments are changed.</p>
          </aside></div>
        </>}
        {stage==='difficult' && <>
          <SectionHeader eyebrow="03 / A DIFFICULT DAY" title={<>When life happens, <em>your pact is ready.</em></>} description="Fast-forward through a financial shock. FLUX checks the rules you authorised on a good day."/>
          <div className="two-columns difficult-grid"><section className="panel"><div className="section-kicker">CUSTOMER'S FUTURE · SIMULATED</div><h2>A financial risk has appeared.</h2><div className="scenario-warning">⚠ &nbsp; The forecast identifies a potential shortfall. FLUX makes no inference about anyone's mental health.</div>
            <div className="switches"><label className="switch-row"><input type="checkbox" checked={shock} disabled={Boolean(execution)} onChange={e=>setShock(e.target.checked)}/><span><strong>Simulate an additional £60 expense</strong><small>Useful for showing when a pact cannot fully solve the problem.</small></span></label><label className="switch-row"><input type="checkbox" checked={missedCheckin} disabled={Boolean(execution)} onChange={e=>setMissedCheckin(e.target.checked)}/><span><strong>Simulate an agreed missed check-in</strong><small>Triggers a neutral alert only if that rule was approved separately.</small></span></label></div>
            <div className="three-mini-metrics"><Metric label="Rent gap before pact" value={money(pactForecast?.before.rentGap ?? 0)} tone="danger"/><Metric label="30-day gap before pact" value={money(pactForecast?.before.horizonGap ?? 0)} tone="danger"/><Metric label="Protected if authorised" value={money(pactForecast?.paused?pact.finances.savings:0)} tone="good"/></div><button className="primary-button wide" disabled={!canRun} onClick={fastForward}>{execution?'Already simulated':'Fast-forward & activate approved protections'} <span>→</span></button><p className="small muted">Triggers use the same 30-day forecast as the chart. No real transactions or messages occur.</p>
          </section><aside className="panel"><div className="section-kicker">POTENTIAL OUTCOME</div><h2>Your approved safety net</h2><div className="mini-chart">{pactForecast && <ForecastChart forecast={pactForecast} rentDay={pact.finances.rentDay} buffer={pact.buffer}/>}</div><p className="chart-warning">After permitted actions, the median reaches {signedMoney(pactForecast?.after.minimum??0)} on day {pactForecast?.after.minDay??'–'}; the remaining 30-day safety gap is {money(pactForecast?.after.horizonGap??0)}.</p><div className="notice">When the pact cannot cover a shortfall, FLUX flags it and offers human support rather than pretending the problem is solved.</div></aside></div>
        </>}
        {stage==='landing' && execution && <>
          <SectionHeader eyebrow="04 / SAFE LANDING" title={result.after.rentGap===0?<>Rent funded. <em>{result.after.horizonGap>0?'A later risk remains.':'Your pact worked.'}</em></>:<>Your pact helped, <em>but rent is still at risk.</em></>} description="A calm, accountable record of what was done — and what still needs attention."/>
          <div className="landing-metrics"><Metric label="Funds retained for essentials" value={money(retained)} tone="good" detail="Simulated optional transfer"/><Metric label="Rent shortfall after pact" value={money(result.after.rentGap)} tone={result.after.rentGap===0?'good':'danger'} detail={`Before: ${money(result.before.rentGap)} short`}/><Metric label="Remaining 30-day safety gap" value={money(result.after.horizonGap)} tone={result.after.horizonGap===0?'good':'danger'} detail={`Lowest median ${signedMoney(result.after.minimum)} on day ${result.after.minDay}`}/></div>
          {result.after.horizonGap>0 && <div className="support-warning"><strong>⚠ More support may still be needed.</strong> {result.after.rentGap>0?`${money(result.after.rentGap)} is still missing for rent. `:'Rent is funded in this scenario, but a later financial gap remains. '}FLUX cannot create money. The hardship letter is ready for your review, and an appropriate human support service may help.</div>}
          <div className="two-columns landing-grid"><section className="panel"><div className="section-kicker">EXACTLY WHAT HAPPENED</div><h2>Activity and audit trail</h2><div className="audit-list">{execution.log.map((item,i)=><div key={i} className="audit-item"><span className={`audit-symbol ${item.kind}`}>{item.kind==='done'?'✓':item.kind==='warn'?'!':'i'}</span><span><strong>{item.title}</strong><small>{item.detail}</small><em>SIMULATED ACTION {String(i+1).padStart(2,'0')}</em></span></div>)}</div></section><aside className="panel"><div className="section-kicker">YOU'RE STILL IN CONTROL</div><h2>Review your next steps</h2><p className="muted">Only the agreed, limited protections ran. Any draft is still awaiting your review.</p><button className="outline-button wide" onClick={()=>setLetterOpen(true)}>Review landlord hardship draft ↗</button><button className="outline-button wide" onClick={editPact}>Edit future pact rules</button><button className="outline-button wide danger-action" disabled={revoked} onClick={revoke}>{revoked?'Future permissions revoked':'Revoke future permissions'}</button><button className="primary-button wide" onClick={reset}>Restart judge demo →</button><p className="small muted">Revoking future permissions does not undo completed actions. This prototype does not make real bank changes.</p></aside></div>
        </>}
      </main>
      <footer className="bottom-footer">FLUX is a fictional NatWest hackathon concept. Synthetic account data and mock banking actions. Not financial, medical or legal advice.</footer>
    </div>
    {letterOpen && <div className="modal-backdrop" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)setLetterOpen(false)}}><section className="modal" role="dialog" aria-modal="true" aria-label="Hardship letter for review"><div className="modal-head"><h2>Hardship letter · draft only</h2><button onClick={()=>setLetterOpen(false)} aria-label="Close letter">✕</button></div><p className="muted small">Never sent automatically. Review all details before using.</p><pre>{createLetter(pact?.finances?.rent??finances.rent)}</pre><button className="primary-button wide" onClick={async()=>{try{await navigator.clipboard.writeText(createLetter(pact?.finances?.rent??finances.rent));clearToast('Draft copied to clipboard. Not sent.');}catch{clearToast('Select the draft text and copy it manually.');}}}>Copy draft for review</button></section></div>}
    {toast && <div role="status" className="toast">{toast}</div>}
  </div>;
}
export default App;
