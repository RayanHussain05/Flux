/**
 * FLUX financial model. Fully deterministic and independent of generative AI.
 * This is illustrative synthetic cash-flow modelling, not benefits advice.
 */
export const DEFAULT_FINANCES = Object.freeze({
  balance: 650, rent: 650, savings: 40, rentDay: 10,
  lostWeeks: 3, extraCost: 0
});

export function clampNumber(v, fallback = 0, min = 0, max = 20000) {
  if (v === '' || v == null) return fallback;
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
}

export function money(value) {
  return `£${Math.round(Math.abs(value)).toLocaleString('en-GB')}`;
}
export function signedMoney(value) {
  return `${value < 0 ? '−' : ''}${money(value)}`;
}
function seeded(seed) {
  return () => {
    let t = seed += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

export function simulatePaths(finances, pauseTransfer = false, extraShock = 0) {
  const cfg = { ...DEFAULT_FINANCES, ...finances };
  const paths = [];
  for (let i = 0; i < 150; i++) {
    const random = seeded(911 + 13 * i);
    let balance = cfg.balance;
    const path = [];
    const surpriseDay = 12 + Math.floor(random() * 3);
    const surpriseSize = Math.floor(random() * 140);
    const variableWages = 90 * Math.max(0, 4 - cfg.lostWeeks) * (0.25 + random() * 1.5);
    const secondExpense = 20 + Math.floor(random() * 150);
    for (let day = 0; day <= 30; day++) {
      if (day === 6 && !pauseTransfer) balance -= cfg.savings;
      if (day === 7) balance -= cfg.extraCost + extraShock;
      if (day === cfg.rentDay) balance -= cfg.rent;
      if (day === surpriseDay) balance -= surpriseSize;
      if (day === 17) balance += 850; // Fictional incoming UC/payment, not a UC estimate.
      if (day === 19) balance -= 70;
      if (day === 24) balance += variableWages;
      if (day === 26) balance -= secondExpense;
      path.push(Math.round(balance));
    }
    paths.push(path);
  }
  return paths;
}

export function summarizePaths(paths, rentDay = 10, safetyBuffer = 0) {
  const bands = Array.from({ length: 31 }, (_, day) => {
    const sorted = paths.map(path => path[day]).sort((a, b) => a - b);
    return {
      low: sorted[Math.floor(sorted.length * 0.10)],
      median: sorted[Math.floor(sorted.length * 0.50)],
      high: sorted[Math.floor(sorted.length * 0.90)]
    };
  });
  const minimum = Math.min(...bands.map(d => d.median));
  const minDay = bands.findIndex(d => d.median === minimum);
  const rentBalance = bands[rentDay].median;
  return {
    bands,
    minimum,
    minDay,
    rentBalance,
    rentGap: Math.max(0, -rentBalance),
    horizonGap: Math.max(0, safetyBuffer - minimum)
  };
}

/** Same model powers the chart, trigger and final result — never diverge. */
export function evaluateForecast(finances, { extraShock = 0, permitPause = true, safetyBuffer = 0 } = {}) {
  const cfg = { ...DEFAULT_FINANCES, ...finances };
  const before = summarizePaths(simulatePaths(cfg, false, extraShock), cfg.rentDay, safetyBuffer);
  const paused = Boolean(permitPause && cfg.savings > 0 && before.horizonGap > 0);
  const after = summarizePaths(simulatePaths(cfg, paused, extraShock), cfg.rentDay, safetyBuffer);
  return { before, after, paused, safetyBuffer, extraShock };
}
