#!/usr/bin/env python3
"""Local FLUX /api/interpret backend using Anthropic's Messages API.

The React/Vite frontend proxies /api requests here. No user text is logged or saved.
Never put ANTHROPIC_API_KEY into JavaScript, .env files in Git, or a shared chat.
The model proposes scenarios only; consent and mock banking are enforced client-side.
"""
import json
import math
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

class ClaudeConnectionError(Exception):
    """User-safe provider error that never contains keys or customer text."""
    pass


HOST = '127.0.0.1'
PORT = int(os.getenv('FLUX_PORT', '8765'))
MODEL = os.getenv('FLUX_CLAUDE_MODEL', 'claude-haiku-5-5')

SYSTEM = """You help a user set up FLUX Good-Day Pact, a fictional financial
advance-planning prototype. User descriptions may include sensitive health information.
Never diagnose, infer mental capacity, assess eligibility for benefits, or offer medical
advice. Never recommend investing, lending, automatically changing rent agreements,
automatically sending letters, or irreversible financial actions. Assume no access to
bank accounts. You only PROPOSE suggestions. All permission decisions are user-made.
Return only a valid JSON object, with no Markdown:
{
  "summary": "A friendly one-sentence summary of the user's financial priorities",
  "insights": [ { "title":"Short heading", "explain":"One sentence of explanation", "icon":"⌂" } ],
  "suggested_rules": ["pause", "draft", "contact"],
  "scenario": { "balance":null, "rent":null, "savings":null, "lostWeeks":null }
}
Give 1-3 short insights. Only suggest rules when relevant to the user's description.
Only fill numeric values when they were EXPLICITLY stated by the user, else null.
Never invent currency amounts, paydays, housing obligations or benefits amounts.
Do not include health diagnoses in output. "pause" means pausing a future OPTIONAL
savings transfer, not a contractual bill. "draft" never sends a letter. "contact"
means a neutral, pre-consented message on a separate opt-in trigger.
"""


def clean_amount(value, limit):
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        return None
    if not math.isfinite(value) or not (0 <= value <= limit):
        return None
    return value


def validate_result(data):
    if not isinstance(data, dict):
        raise ValueError('Not a JSON object')
    summary = data.get('summary', '')
    if not isinstance(summary, str):
        raise ValueError('Summary must be text')
    insights = data.get('insights', [])
    if not isinstance(insights, list):
        raise ValueError('Insights must be a list')
    raw_suggestions = data.get('suggested_rules', [])
    if not isinstance(raw_suggestions, list):
        raw_suggestions = []
    scenario = data.get('scenario') or {}
    if not isinstance(scenario, dict):
        scenario = {}
    rules = []
    for value in raw_suggestions:
        if value in ('pause', 'draft', 'contact') and value not in rules:
            rules.append(value)
    clean_insights = []
    for insight in insights[:3]:
        if not isinstance(insight, dict):
            continue
        icon = insight.get('icon', '✧')
        clean_insights.append({
            'icon': icon if icon in ('⌂', '◷', '✧') else '✧',
            'title': str(insight.get('title', 'A financial priority'))[:70],
            'explain': str(insight.get('explain', 'Review your options'))[:180],
        })
    return {
        'mode': 'live-ai',
        'summary': summary[:360],
        'insights': clean_insights,
        'suggested_rules': rules,
        'scenario': {
            'balance': clean_amount(scenario.get('balance'), 20000),
            'rent': clean_amount(scenario.get('rent'), 20000),
            'savings': clean_amount(scenario.get('savings'), 5000),
            'lostWeeks': clean_amount(scenario.get('lostWeeks'), 4),
        },
    }


# Ask Claude for parseable, constrained output rather than relying on free-form JSON.
NUMERIC = {"anyOf": [{"type": "number"}, {"type": "null"}]}
OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "summary": {"type": "string"},
        "insights": {"type": "array", "items": {
            "type": "object", "properties": {
                "title": {"type": "string"},
                "explain": {"type": "string"},
                "icon": {"type": "string"},
            }, "required": ["title", "explain", "icon"], "additionalProperties": False,
        }},
        "suggested_rules": {"type": "array", "items": {"type": "string", "enum": ["pause", "draft", "contact"]}},
        "scenario": {"type": "object", "properties": {
            "balance": NUMERIC, "rent": NUMERIC, "savings": NUMERIC, "lostWeeks": NUMERIC,
        }, "required": ["balance", "rent", "savings", "lostWeeks"], "additionalProperties": False},
    },
    "required": ["summary", "insights", "suggested_rules", "scenario"],
    "additionalProperties": False,
}


def claude_error_message(status):
    reasons = {
        400: 'Anthropic rejected the request (400). Check model and API settings.',
        401: 'API key rejected or revoked (401). Create a fresh key and restart the Python server.',
        402: 'Anthropic billing/credits issue (402). Check your promotional balance.',
        403: 'Key or organization lacks permission for this model (403).',
        404: f'Model {MODEL} unavailable (404). Check model access or set FLUX_CLAUDE_MODEL.',
        429: 'Rate limit reached (429). Retry after a short interval.',
        529: 'Claude is temporarily overloaded (529). Retry shortly.',
    }
    return reasons.get(status, f'Claude API returned HTTP {status}. Check the Python terminal.')


def call_claude(story):
    key = os.getenv('ANTHROPIC_API_KEY', '')
    if not key:
        raise ClaudeConnectionError('Claude API key is missing. Set ANTHROPIC_API_KEY in this PowerShell terminal and restart the backend.')
    payload = {
        'model': MODEL,
        'max_tokens': 1500,
        'system': SYSTEM,
        'messages': [{'role': 'user', 'content': story}],
        'output_config': {'format': {'type': 'json_schema', 'schema': OUTPUT_SCHEMA}},
    }
    request = Request(
        'https://api.anthropic.com/v1/messages',
        data=json.dumps(payload).encode('utf-8'), method='POST',
        headers={
            'Content-Type': 'application/json', 'x-api-key': key,
            'anthropic-version': '2023-06-01',
        },
    )
    try:
        with urlopen(request, timeout=28) as response:
            reply = json.loads(response.read(140000))
    except HTTPError as exc:
        raise ClaudeConnectionError(claude_error_message(exc.code)) from exc
    except URLError as exc:
        raise ClaudeConnectionError('Cannot reach Anthropic from the Python server. Check internet access.') from exc
    except TimeoutError as exc:
        raise ClaudeConnectionError('Claude timed out. Please retry.') from exc
    except json.JSONDecodeError as exc:
        raise ClaudeConnectionError('Claude returned an unreadable HTTP response.') from exc
    text_parts = [part.get('text', '') for part in reply.get('content', []) if part.get('type') == 'text']
    raw_text = '\n'.join(text_parts).strip()
    if raw_text.startswith('```'):
        raw_text = raw_text.split('\n', 1)[-1].rsplit('```', 1)[0].strip()
    try:
        return validate_result(json.loads(raw_text))
    except (ValueError, json.JSONDecodeError) as exc:
        raise ClaudeConnectionError('Claude returned an unexpected JSON response. Please retry.') from exc


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # No request body or health information is logged.
        print(f'[FLUX API] {self.command} {self.path} {args[1] if len(args)>1 else ""}')

    def reply(self, status, body):
        data = json.dumps(body, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == '/api/health':
            self.reply(200, {'status': 'ok', 'claude_configured': bool(os.getenv('ANTHROPIC_API_KEY'))})
        else:
            self.reply(404, {'error': 'Not found'})

    def do_POST(self):
        if self.path != '/api/interpret':
            self.reply(404, {'error': 'Not found'})
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 6000:
                raise ValueError('Invalid request size')
            raw = json.loads(self.rfile.read(length))
            story = raw.get('story', '')
            if not isinstance(story, str) or not (12 <= len(story) <= 2400):
                raise ValueError('Description should be 12–2400 characters')
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
            self.reply(400, {'error': 'Please provide a valid description'})
            return
        try:
            self.reply(200, call_claude(story))
        except ClaudeConnectionError as exc:
            print('Claude call unavailable:', type(exc).__name__)  # Never print the key or story.
            self.reply(502, {'error': str(exc)})
        except Exception as exc:
            print('Unexpected Claude error:', type(exc).__name__)
            self.reply(502, {'error': 'Unexpected backend error. Check the Python terminal and try again.'})


if __name__ == '__main__':
    print(f'FLUX Claude API listening on http://{HOST}:{PORT}')
    print('Live Claude:', 'configured' if os.getenv('ANTHROPIC_API_KEY') else 'not configured — offline frontend still works')
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
