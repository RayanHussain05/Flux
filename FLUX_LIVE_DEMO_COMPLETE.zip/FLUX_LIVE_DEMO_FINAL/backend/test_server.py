import unittest
from server import validate_result, clean_amount

class ApiOutputTests(unittest.TestCase):
    def test_whitelist(self):
        result=validate_result({
            'summary':'Help protect the rent',
            'insights':[{'title':'Housing','explain':'The rent is essential','icon':'⌂'}],
            'suggested_rules':['pause','pause','contact','give_admin_access'],
            'scenario':{'balance':650,'rent':650,'savings':40,'lostWeeks':3},
        })
        self.assertEqual(result['suggested_rules'], ['pause', 'contact'])
        self.assertEqual(result['scenario']['rent'],650)
        self.assertEqual(result['mode'],'live-ai')
    def test_invalid_figures(self):
        self.assertIsNone(clean_amount(-4,20000))
        self.assertIsNone(clean_amount('£650',20000))
        self.assertIsNone(clean_amount(True,20000))
    def test_bad_scenario_rejected(self):
        result=validate_result({'summary':'A','insights':[],'scenario':{'rent':999999}})
        self.assertIsNone(result['scenario']['rent'])

if __name__=='__main__':unittest.main()
