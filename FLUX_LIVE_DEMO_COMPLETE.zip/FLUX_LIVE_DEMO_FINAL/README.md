# FLUX — FINAL LIVE DEMO (Windows)

**Fastest route:** Extract this entire folder. Double-click `START_FLUX_WINDOWS.bat`.
The launcher installs npm dependencies (first run only), privately asks for a **new**
Claude key (Enter = offline), starts React and Python together and opens
`http://127.0.0.1:5173/`. Keep the launcher window open.

Use only fictional user stories. The demo **does not connect to NatWest** or send real
messages. If live Claude fails, untick its option and use the offline rules.

See `LIVE_DEMO_INSTRUCTIONS.txt` for the exact click path and `TALK_TRACK_2_MINUTES.md`
for the presenter script. `FALLBACK_OFFLINE.html` is an HTML-only backup if npm or the
internet fails, and is not a React build.

---

# FLUX — Good-Day Pact (React + Claude)

A GreatUniHack 2026 NatWest challenge prototype: make financial decisions on a good day and rehearse how a narrowly pre-authorised rule could protect essentials on a difficult day.

## Project stack

- **React 19 + Vite 7** — all 4 interactive screens
- **Plain CSS** — responsive, no component-library dependence
- **JavaScript model** (`src/finance.js`) — deterministic 30-day cash-flow simulations (150 synthetic paths) and uncertainty bands
- **Consent-gated rules** — snapshot of pre-authorised permissions, mock payment actions, audit trail and revocation
- **Python standard-library backend** (`backend/server.py`) — optional Anthropic Claude API for language understanding
- **No real bank account or data** — simulated transfers, notifications, rent and benefit payments

## Windows quick start

1. Extract the ZIP and open the folder in VS Code.
2. Open a VS Code terminal in this folder.
3. Install frontend dependencies (internet needed on first install):

   ```powershell
   npm install
   ```

4. Start the React app:

   ```powershell
   npm run dev
   ```

5. Open **http://127.0.0.1:5173** in Chrome/Edge.

This already runs the full prototype **without a Claude key**, in visibly labelled offline rule-based mode.

### Enable real Claude AI (optional)

**First revoke the key exposed in chat and generate a new key. Never put a key in `src/`, `index.html`, or any `VITE_` variable.**

In a **second** terminal, inside the project folder:

```powershell
$env:ANTHROPIC_API_KEY="YOUR_NEW_PRIVATE_KEY"
python backend/server.py
```

Keep both terminals open. The Vite app proxies `/api` requests to localhost port 8765. In the Rehearse screen, tick **Use live Claude AI** and click **Understand my situation**. Model suggestions appear for customer review. They never auto-authorise actions.

You can optionally override the model for one terminal session using `FLUX_CLAUDE_MODEL`. The default is `claude-haiku-5-5`, subject to model availability in your Anthropic account.

### macOS/Linux

Terminal 1: `npm install && npm run dev`

Terminal 2: `export ANTHROPIC_API_KEY='YOUR_NEW_PRIVATE_KEY'; python3 backend/server.py`

## Demo path (90–120 seconds)

1. **Rehearse:** Show the default customer story, click Understand, point to financial time travel and range of outcomes.
2. **Make your pact:** Choose optional-transfer pause and draft-only letter, approve consent and click Authorise.
3. **Difficult day:** Click Fast-forward. The rules check the **same** financial model as the chart.
4. **Safe landing:** £40 retained; £0 rent gap **but £77 later 30-day safety risk**. Show audit trail and letter.
5. **For Q&A:** Reset, repeat with the £60 shock on. It shows **£60 rent gap** and **£137 30-day gap** — the pact openly admits it has not solved everything.

## Tests

```bash
npm test
npm run build
```

`npm test` tests the finance logic without installing React. `npm run build` requires `npm install` first.

## Safety and data handling

- The UI and code use a **fictional** Alex persona and made-up cash flows. The £850 payment on day 17 is an invented payment, not a real or expected UC entitlement.
- The simulation models finances, not mental health episodes, diagnoses or capacity.
- Live Claude requests send **only the user's written description** to Anthropic, with explicit opt-in. The React client cannot read the private API key.
- The Python backend does not save or log story text, but Anthropic's own API data handling policies apply to API requests. For this event use synthetic user stories only.
- The pact's authorisation is distinct from AI proposals. Only a specific approval and the deterministic risk trigger can pause a **simulated optional transfer**.
- A drafted landlord letter is not sent. The landlord would need to agree to any proposed rent change.
- The trusted-person message is one simulated opt-in notification, not a live SMS. There is no claimed recurring cooldown feature.
- Revoking permission prevents future mock actions; it cannot reverse past actions.
- This is **not** a NatWest product, a production financial service, a bank integration, or an operational safeguards implementation.

## Files

- `src/App.jsx` — actual React application
- `src/finance.js` — shared forecast/trigger math
- `src/finance.test.js` — finance regression tests
- `src/style.css` — styling
- `backend/server.py` — Claude API backend (server-side only)
- `vite.config.js` — Vite dev proxy for Python backend
- `package.json` — React dependencies and dev scripts
- `PITCH.md` — presenter walkthrough
