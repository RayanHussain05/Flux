#!/usr/bin/env python3
"""One-console FLUX hackathon launcher (Windows-friendly, no key stored)."""
import os
import shutil
import subprocess
import sys
import time
import webbrowser
from getpass import getpass
from pathlib import Path
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent
BACKEND = 'http://127.0.0.1:8765/api/health'
FRONTEND = 'http://127.0.0.1:5173/'


def can_get(url):
    try:
        with urlopen(url, timeout=1.5) as result:
            return result.status == 200
    except Exception:
        return False


def main():
    print('\n' + '=' * 58)
    print(' FLUX · GOOD-DAY PACT — NATWEST HACKATHON LIVE DEMO')
    print('=' * 58)
    npm = shutil.which('npm.cmd') if os.name == 'nt' else shutil.which('npm')
    if not npm:
        print('\nERROR: Node.js/npm not found. Install Node.js LTS from https://nodejs.org/.')
        return 1

    if not (ROOT / 'node_modules' / 'vite').exists():
        print('\n[1/4] Installing React dependencies (first run only)…')
        proc = subprocess.run([npm, 'install', '--no-audit', '--no-fund'], cwd=ROOT)
        if proc.returncode != 0:
            print('npm install failed; check your internet connection and Node.js installation.')
            return 1
    else:
        print('\n[1/4] React dependencies already installed.')

    print('\n[2/4] Claude AI connection')
    print('For LIVE Claude, paste a fresh private API key at the hidden prompt.')
    print('Press Enter to run safely offline instead.')
    print('The key stays only in this process and is never written to the project.')
    if os.environ.get('ANTHROPIC_API_KEY'):
        print('A Claude key is already set in this terminal; it will be used.')
        key = os.environ['ANTHROPIC_API_KEY']
    else:
        try:
            key = getpass('New Claude API key (input hidden, Enter = offline): ').strip()
        except (EOFError, KeyboardInterrupt):
            print('\nNo key entered; continuing offline.')
            key = ''

    env = dict(os.environ)
    if key:
        env['ANTHROPIC_API_KEY'] = key
    else:
        env.pop('ANTHROPIC_API_KEY', None)

    if can_get(BACKEND) or can_get(FRONTEND):
        print('\nAnother copy of FLUX is already running on port 8765 or 5173.')
        print('Close its Python/React terminal using Ctrl+C, then launch FLUX again.')
        return 1

    processes = []
    try:
        print('\n[3/4] Starting Claude backend + React frontend…')
        processes.append(subprocess.Popen([sys.executable, '-u', 'backend/server.py'], cwd=ROOT, env=env))
        processes.append(subprocess.Popen([npm, 'run', 'dev'], cwd=ROOT, env={k:v for k,v in env.items() if k != 'ANTHROPIC_API_KEY'}))

        for _ in range(70):
            if can_get(FRONTEND) and can_get(BACKEND):
                break
            for p in processes:
                if p.poll() is not None:
                    print('A server stopped unexpectedly. Read the error above.')
                    return 1
            time.sleep(.3)
        else:
            print('Servers did not become ready. Read the messages above.')
            return 1

        print('\n[4/4] READY!')
        print('React frontend: ' + FRONTEND)
        print('Claude backend:  ' + BACKEND)
        print('Claude status:   ' + ('KEY PROVIDED (test a live response in the UI)' if key else 'OFFLINE ONLY'))
        print('\nFor a live response tick "Use live Claude AI" then click "Understand my situation".')
        print('The forecast and mock bank actions work even if Claude is unavailable.')
        print('Keep this window OPEN during the demo. Press Ctrl+C to stop both servers.\n')
        webbrowser.open(FRONTEND)
        while all(p.poll() is None for p in processes):
            time.sleep(.6)
        print('One FLUX server stopped. See errors above.')
        return 1
    except KeyboardInterrupt:
        print('\nStopping FLUX servers...')
        return 0
    finally:
        for proc in processes:
            if proc.poll() is None:
                proc.terminate()
        for proc in processes:
            try:
                proc.wait(timeout=4)
            except subprocess.TimeoutExpired:
                proc.kill()


if __name__ == '__main__':
    raise SystemExit(main())
