@echo off
setlocal
cd /d "%~dp0"
title FLUX Good-Day Pact - Launcher
where python >nul 2>&1
if %errorlevel%==0 (
  python START_FLUX.py
) else (
  where py >nul 2>&1
  if %errorlevel%==0 (
    py -3 START_FLUX.py
  ) else (
    echo Python 3 was not found. Install Python or launch START_FLUX.py with an installed Python 3 interpreter.
  )
)
echo.
echo Press any key to close this launcher.
pause >nul
