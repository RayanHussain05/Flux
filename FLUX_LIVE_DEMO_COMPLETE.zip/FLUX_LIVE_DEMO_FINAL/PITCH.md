# Presentation cue card — FLUX Good-Day Pact

**Opening (30 seconds):** "Imagine you’re in the middle of a severe depressive episode. Your rent is due. You know you should contact your landlord, but you cannot face opening your bank app. Most financial tools assume that when a crisis hits, you can act. But what if you can’t?"

**Innovation (20 seconds):** "On a good day, you prepare for a difficult one. FLUX lets you rehearse how your money could change, then choose the precise rules the bank could follow later. Nothing is authorised by a language model."

**Demonstration (~90 seconds):** Rehearse → Make your pact → Authorise → Difficult day → Fast-forward → Safe landing. On a good day Alex pre-approves pausing an *optional* £40 savings transfer. At the risk trigger, mock banking retains £40 for £650 rent. The immediate gap closes, but a £77 later 30-day safety gap remains. Show the audit trail. For judges, toggle £60 shock after reset; the prototype says rent is still £60 short and flags £137 30-day risk.

**AI and ethics (20 seconds):** "Claude helps translate everyday descriptions into suggested goals, rules and plain-English explanations. The customer confirms numbers and permissions. Our cash-flow calculations and rule execution are deterministic. Live requests require opt-in; the demo uses fictional data." 

**Feasibility (10 seconds):** "This is a proposed NatWest-native experience using mocked payments. Rent changes need landlord consent, and we never imply an actual payment or notification has occurred."

**Close (10 seconds):** "We’re not building AI to replace people’s decisions. We’re building AI that helps people honour decisions they’ve already made for themselves."

**Questions to anticipate:**
- "Where does the money come from?" We don't create any. We protect existing funds and surface any remaining gap.
- "What if it fails?" It explicitly flags unresolved rent and later balance shortfalls, and prepares draft-only support requests.
- "What is actually new?" Combining financial rehearsal, customer-authorised rules, and bounded protective action during reduced ability to handle admin.
- "Does the bank already support this?" No. Payment changes are simulated; a real implementation would need bank-side integration, security review and operational safeguards.
